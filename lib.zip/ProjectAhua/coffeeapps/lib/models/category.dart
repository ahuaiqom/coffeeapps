class Category {
  final String id;
  final String label;

  Category({required this.id, required this.label});
}
