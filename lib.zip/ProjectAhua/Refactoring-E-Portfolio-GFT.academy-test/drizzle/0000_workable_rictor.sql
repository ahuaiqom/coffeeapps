CREATE TABLE `drafts` (
	`id` varchar(36) NOT NULL,
	`user_id` int NOT NULL,
	`kind` varchar(50),
	`src_ref` varchar(36),
	`content_md` varchar(1000),
	`status` varchar(20) DEFAULT 'ready',
	`created_at` datetime DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT `drafts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `projects` (
	`id` varchar(36) NOT NULL,
	`user_id` int NOT NULL,
	`title` varchar(255),
	`org` varchar(255),
	`role` varchar(100),
	`start_at` datetime,
	`end_at` datetime,
	`outcomes` varchar(500),
	`tech_stack` json,
	CONSTRAINT `projects_id` PRIMARY KEY(`id`)
);
