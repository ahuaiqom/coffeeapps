import { json } from "@sveltejs/kit";
import { db } from "$lib/server/db";
import { drafts } from "$lib/server/db/schema";

// GET /api/drafts → ambil semua draft
export async function GET() {
  const data = await db.select().from(drafts);
  return json(data);
}

// POST /api/drafts → tambah draft baru
export async function POST({ request }) {
  const body = await request.json();
  await db.insert(drafts).values(body);
  return json({ message: "Draft created ✅" });
}
