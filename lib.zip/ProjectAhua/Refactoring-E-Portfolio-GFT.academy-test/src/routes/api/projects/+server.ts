import { json } from "@sveltejs/kit";
import { db } from "$lib/server/db/index";
import { projects } from "$lib/server/db/schema";

// GET /api/projects
export async function GET() {
  const data = await db.select().from(projects);
  return json(data);
}

// POST /api/projects
export async function POST({ request }: { request: Request }) {
  console.log(request);
  const body = await request.json();

  await db.insert(projects).values({
    id: body.id,
    userId: body.userId,
    title: body.title,
    org: body.org,
    role: body.role,
    outcomes: body.outcomes,
    techStack: body.techStack,
  });

  return json({ message: "Project created ✅" });
}
