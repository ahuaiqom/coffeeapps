import { json } from "@sveltejs/kit";
import { db } from "$lib/server/db";
import { projects } from "$lib/server/db/schema";
import { eq } from "drizzle-orm";

// GET /api/projects/:id → ambil project by id
export async function GET({ params }) {
  const data = await db.select().from(projects).where(eq(projects.id, params.id));
  return json(data[0] ?? { message: "Not found" });
}

// PUT /api/projects/:id → update project
export async function PUT({ params, request }) {
  const body = await request.json();
  await db.update(projects).set(body).where(eq(projects.id, params.id));
  return json({ message: `Project ${params.id} updated ✅` });
}

// DELETE /api/projects/:id → hapus project
export async function DELETE({ params }) {
  await db.delete(projects).where(eq(projects.id, params.id));
  return json({ message: `Project ${params.id} deleted ❌` });
}
