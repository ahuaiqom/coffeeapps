<script lang="ts">
  export let data;
  let projects = data.projects;

  let title = "";
  let org = "";
  let role = "";
  let outcomes = "";
  let techStack = "";

  // Tambah project baru
  async function addProject() {
    const res = await fetch("/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: crypto.randomUUID(),
        userId: 1,
        title,
        org,
        role,
        outcomes,
        techStack: { backend: "Node.js", db: "MySQL" }
      })
    });
    if (res.ok) {
      projects = [
        ...projects,
        {
          id: crypto.randomUUID(),
          userId: 1,
          title,
          org,
          role,
          startAt: null,
          endAt: null,
          outcomes,
          techStack: { backend: "Node.js", db: "MySQL" }
        }
      ];
      title = org = role = outcomes = techStack = "";
      alert("✅ Project created");
    }
  }

  // Hapus project
  async function deleteProject(id: string) {
    const res = await fetch(`/api/projects/${id}`, { method: "DELETE" });
    if (res.ok) {
      projects = projects.filter((p) => p.id !== id);
      alert("❌ Project deleted");
    }
  }
</script>

<h1 class="text-2xl font-bold mb-4">📂 Projects</h1>

<!-- Form tambah project -->
<form on:submit|preventDefault={addProject} class="space-y-2 mb-6">
  <input bind:value={title} placeholder="Title" class="border p-2 w-full"/>
  <input bind:value={org} placeholder="Organization" class="border p-2 w-full"/>
  <input bind:value={role} placeholder="Role" class="border p-2 w-full"/>
  <input bind:value={outcomes} placeholder="Outcomes" class="border p-2 w-full"/>
  <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">
    Add Project
  </button>
</form>

<!-- List project -->
<ul class="space-y-2">
  {#each projects as project}
    <li class="p-4 border rounded flex justify-between items-center">
      <div>
        <p class="font-semibold">{project.title}</p>
        <p class="text-sm text-gray-600">{project.org} | {project.role}</p>
        <p class="text-sm">{project.outcomes}</p>
      </div>
      <div class="flex gap-2">
        <a href={`/projects/${project.id}`} class="bg-yellow-500 text-white px-3 py-1 rounded">
          Edit
        </a>
        <button
          on:click={() => deleteProject(project.id)}
          class="bg-red-500 text-white px-3 py-1 rounded"
        >
          Delete
        </button>
      </div>
    </li>
  {/each}
</ul>
