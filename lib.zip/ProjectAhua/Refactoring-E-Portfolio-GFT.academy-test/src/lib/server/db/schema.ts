import { mysqlTable, varchar, int, json, datetime } from "drizzle-orm/mysql-core";
import { sql } from "drizzle-orm";

export const projects = mysqlTable("projects", {
  id: varchar("id", { length: 36 }).primaryKey(),
  userId: int("user_id").notNull(),
  title: varchar("title", { length: 255 }),
  org: varchar("org", { length: 255 }),
  role: varchar("role", { length: 100 }),
  startAt: datetime("start_at"),
  endAt: datetime("end_at"),
  outcomes: varchar("outcomes", { length: 500 }),
  techStack: json("tech_stack"),
});

export const drafts = mysqlTable("drafts", {
  id: varchar("id", { length: 36 }).primaryKey(),
  userId: int("user_id").notNull(),
  kind: varchar("kind", { length: 50 }),
  srcRef: varchar("src_ref", { length: 36 }),
  contentMd: varchar("content_md", { length: 1000 }),
  status: varchar("status", { length: 20 }).default("ready"),
  createdAt: datetime("created_at").default(sql`CURRENT_TIMESTAMP`),
});
