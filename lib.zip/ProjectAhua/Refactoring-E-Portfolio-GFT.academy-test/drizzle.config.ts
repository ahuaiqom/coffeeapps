import { defineConfig } from "drizzle-kit";

export default defineConfig({
  schema: "./src/lib/server/db/schema.ts", // ⬅️ sesuai lokasi file kamu
  out: "./drizzle",
  dialect: "mysql",
  dbCredentials: {
    host: "localhost",
    user: "root",
    password: undefined, // default XAMPP MySQL tidak ada password
    database: "portfolio_db",
  },
});
