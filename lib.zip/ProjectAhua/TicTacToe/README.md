# TicTacToe - Java (OOP)


Simple console-based TicTacToe implemented with OOP principles.


How to compile & run (from project root):


```bash
javac -d out src/*.java
java -cp out Main
```


Files are small and self-contained; no external libraries required.