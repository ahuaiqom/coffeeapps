import java.util.ArrayList;
import java.util.List;

public class Board {
    private final Mark[][] grid;
    public static final int SIZE = 3;

    public Board() {
        grid = new Mark[SIZE][SIZE];
        clear();
    }

    public void clear() {
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                grid[r][c] = Mark.EMPTY;
            }
        }
    }

    public boolean placeMark(int row, int col, Mark mark) {
        if (row < 0 || row >= SIZE || col < 0 || col >= SIZE) return false;
        if (grid[row][col] != Mark.EMPTY) return false;
        grid[row][col] = mark;
        return true;
    }

    public boolean isFull() {
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                if (grid[r][c] == Mark.EMPTY) return false;
            }
        }
        return true;
    }

    public Mark get(int row, int col) {
        return grid[row][col];
    }

    public List<Move> availableMoves() {
        List<Move> moves = new ArrayList<>();
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                if (grid[r][c] == Mark.EMPTY) moves.add(new Move(r, c));
            }
        }
        return moves;
    }

    public Mark checkWinner() {
        // rows
        for (int r = 0; r < SIZE; r++) {
            if (grid[r][0] != Mark.EMPTY && grid[r][0] == grid[r][1] && grid[r][1] == grid[r][2])
                return grid[r][0];
        }
        // cols
        for (int c = 0; c < SIZE; c++) {
            if (grid[0][c] != Mark.EMPTY && grid[0][c] == grid[1][c] && grid[1][c] == grid[2][c])
                return grid[0][c];
        }
        // diagonals
        if (grid[0][0] != Mark.EMPTY && grid[0][0] == grid[1][1] && grid[1][1] == grid[2][2])
            return grid[0][0];
        if (grid[0][2] != Mark.EMPTY && grid[0][2] == grid[1][1] && grid[1][1] == grid[2][0])
            return grid[0][2];

        // tidak ada pemenang
        return Mark.EMPTY;
    }

    public void print() {
        System.out.println();
        for (int r = 0; r < SIZE; r++) {
            System.out.print(" ");
            for (int c = 0; c < SIZE; c++) {
                System.out.print(" " + grid[r][c].toString() + " ");
                if (c < SIZE - 1) System.out.print("|");
            }
            System.out.println();
            if (r < SIZE - 1) System.out.println("---+---+---");
        }
        System.out.println();
    }
}
