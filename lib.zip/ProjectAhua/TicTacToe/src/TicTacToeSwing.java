import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Single-file Swing TicTacToe application.
 * Save as TicTacToeSwing.java
 */
public class TicTacToeSwing extends JFrame {
    private final JButton[][] buttons = new JButton[3][3];
    private final JLabel statusLabel = new JLabel("Welcome to TicTacToe");
    private final JComboBox<String> modeCombo = new JComboBox<>(new String[] {"Human vs Human", "Human vs AI"});
    private final JButton restartBtn = new JButton("Restart");

    private final Board board = new Board();
    private Mark current = Mark.X;
    private boolean gameOver = false;
    private final Random rand = new Random();

    public TicTacToeSwing() {
        super("TicTacToe - Swing (OOP)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8,8));
        add(createTopPanel(), BorderLayout.NORTH);
        add(createBoardPanel(), BorderLayout.CENTER);
        add(createBottomPanel(), BorderLayout.SOUTH);
        pack();
        setResizable(false);
        setLocationRelativeTo(null);
        updateStatus();
    }

    private JPanel createTopPanel() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 6));
        p.add(new JLabel("Mode:"));
        p.add(modeCombo);
        p.add(restartBtn);

        restartBtn.addActionListener(e -> {
            board.clear();
            current = Mark.X;
            gameOver = false;
            refreshButtons();
            updateStatus();
        });

        modeCombo.addActionListener(e -> {
            // if switching to human vs ai while game ongoing, do nothing complex.
            // just update status and continue.
            updateStatus();
        });

        return p;
    }

    private JPanel createBoardPanel() {
        JPanel grid = new JPanel(new GridLayout(3,3,4,4));
        grid.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
        Font font = new Font(Font.SANS_SERIF, Font.BOLD, 48);

        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                JButton b = new JButton(" ");
                b.setFont(font);
                b.setFocusPainted(false);
                final int rr = r;
                final int cc = c;
                b.addActionListener(e -> onCellClicked(rr, cc));
                buttons[r][c] = b;
                grid.add(b);
            }
        }
        return grid;
    }

    private JPanel createBottomPanel() {
        JPanel p = new JPanel(new BorderLayout());
        statusLabel.setBorder(BorderFactory.createEmptyBorder(6,10,6,10));
        p.add(statusLabel, BorderLayout.CENTER);
        return p;
    }

    private void onCellClicked(int row, int col) {
        if (gameOver) return;
        // if cell occupied, ignore
        if (!board.placeMark(row, col, current)) {
            Toolkit.getDefaultToolkit().beep();
            return;
        }
        refreshButtons();

        Mark winner = board.checkWinner();
        if (winner != Mark.EMPTY) {
            statusLabel.setText("Winner: " + winner);
            gameOver = true;
            return;
        }
        if (board.isFull()) {
            statusLabel.setText("It's a draw!");
            gameOver = true;
            return;
        }

        // switch turn
        current = (current == Mark.X) ? Mark.O : Mark.X;
        updateStatus();

        // If now AI's turn and mode is Human vs AI, let AI move
        if (!gameOver && isAIMode() && current == Mark.O) {
            // small delay so UI updates nicely
            Timer t = new Timer(300, ev -> {
                aiMakeMove();
                ((Timer) ev.getSource()).stop();
            });
            t.setRepeats(false);
            t.start();
        }
    }

    private boolean isAIMode() {
        return modeCombo.getSelectedIndex() == 1;
    }

    private void aiMakeMove() {
        List<Move> moves = board.availableMoves();
        if (moves.isEmpty()) return;
        Move pick = moves.get(rand.nextInt(moves.size()));
        board.placeMark(pick.row, pick.col, current);
        refreshButtons();

        Mark winner = board.checkWinner();
        if (winner != Mark.EMPTY) {
            statusLabel.setText("Winner: " + winner);
            gameOver = true;
            return;
        }
        if (board.isFull()) {
            statusLabel.setText("It's a draw!");
            gameOver = true;
            return;
        }
        current = (current == Mark.X) ? Mark.O : Mark.X;
        updateStatus();
    }

    private void refreshButtons() {
        for (int r=0;r<3;r++){
            for (int c=0;c<3;c++){
                buttons[r][c].setText(board.get(r,c).toString());
            }
        }
    }

    private void updateStatus() {
        if (gameOver) return;
        String modeText = isAIMode() ? "Human vs AI" : "Human vs Human";
        statusLabel.setText(String.format("Mode: %s — Current: %s", modeText, current));
    }

    public static void main(String[] args) {
        // ensure Swing UI created in EDT
        SwingUtilities.invokeLater(() -> {
            TicTacToeSwing app = new TicTacToeSwing();
            app.setVisible(true);
        });
    }

    // ---- Supporting classes (OOP) ----

    enum Mark {
        X, O, EMPTY;

        @Override
        public String toString() {
            switch (this) {
                case X: return "X";
                case O: return "O";
                default: return " ";
            }
        }
    }

    static class Move {
        public final int row, col;
        public Move(int r, int c) { row = r; col = c; }
    }

    static class Board {
        private final Mark[][] grid = new Mark[3][3];

        public Board() { clear(); }

        public void clear() {
            for (int r = 0; r < 3; r++) {
                for (int c = 0; c < 3; c++) grid[r][c] = Mark.EMPTY;
            }
        }

        public boolean placeMark(int row, int col, Mark mark) {
            if (row < 0 || row >= 3 || col < 0 || col >= 3) return false;
            if (grid[row][col] != Mark.EMPTY) return false;
            grid[row][col] = mark;
            return true;
        }

        public Mark get(int r, int c) { return grid[r][c]; }

        public boolean isFull() {
            for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) if (grid[r][c] == Mark.EMPTY) return false;
            return true;
        }

        public List<Move> availableMoves() {
            List<Move> moves = new ArrayList<>();
            for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) if (grid[r][c] == Mark.EMPTY) moves.add(new Move(r,c));
            return moves;
        }

        public Mark checkWinner() {
            // rows
            for (int r = 0; r < 3; r++) {
                if (grid[r][0] != Mark.EMPTY && grid[r][0] == grid[r][1] && grid[r][1] == grid[r][2]) return grid[r][0];
            }
            // cols
            for (int c = 0; c < 3; c++) {
                if (grid[0][c] != Mark.EMPTY && grid[0][c] == grid[1][c] && grid[1][c] == grid[2][c]) return grid[0][c];
            }
            // diagonals
            if (grid[0][0] != Mark.EMPTY && grid[0][0] == grid[1][1] && grid[1][1] == grid[2][2]) return grid[0][0];
            if (grid[0][2] != Mark.EMPTY && grid[0][2] == grid[1][1] && grid[1][1] == grid[2][0]) return grid[0][2];

            return Mark.EMPTY;
        }
    }
}
