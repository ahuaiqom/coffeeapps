import java.util.Scanner;


public class HumanPlayer extends Player {
private final Scanner scanner;


public HumanPlayer(Mark mark, Scanner scanner) {
super(mark);
this.scanner = scanner;
}


@Override
public Move decideMove(Board board) {
while (true) {
System.out.print("Enter row (1-3) and column (1-3), separated by space: ");
String line = scanner.nextLine();
String[] parts = line.trim().split("\\s+");
if (parts.length < 2) {
System.out.println("Please enter two numbers.");
continue;
}
try {
int r = Integer.parseInt(parts[0]) - 1;
int c = Integer.parseInt(parts[1]) - 1;
if (board.placeMark(r, c, mark)) {
return new Move(r, c);
} else {
System.out.println("Invalid move, cell occupied or out of range. Try again.");
}
} catch (NumberFormatException e) {
System.out.println("Invalid input. Use numbers 1-3.");
}
}
}
}