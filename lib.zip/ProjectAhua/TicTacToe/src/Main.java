import java.util.Scanner;


public class Main {
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
Board board = new Board();


System.out.println("TicTacToe - OOP Java (Console)");
System.out.println("Choose mode: 1 = Human vs Human, 2 = Human vs AI");
String mode = scanner.nextLine();


Player p1 = new HumanPlayer(Mark.X, scanner);
Player p2;
if (mode.trim().equals("2")) {
p2 = new AIPlayer(Mark.O);
System.out.println("You (X) vs AI (O)");
} else {
p2 = new HumanPlayer(Mark.O, scanner);
System.out.println("Player 1 = X, Player 2 = O");
}


Player current = p1;
board.print();


while (true) {
System.out.println("Current: " + current.getMark());
Move move = current.decideMove(board);
// if human placed the mark inside decideMove, we already placed it there (HumanPlayer places directly).
// For AI, we need to place the mark now.
if (current instanceof AIPlayer) {
if (move != null) board.placeMark(move.row, move.col, current.getMark());
}


board.print();


Mark winner = board.checkWinner();
if (winner != Mark.EMPTY) {
System.out.println("Winner: " + winner);
break;
} else if (board.isFull()) {
System.out.println("It's a draw!");
break;
}


current = (current == p1) ? p2 : p1;
}


scanner.close();
}
}