public abstract class Player {
protected final Mark mark;


public Player(Mark mark) {
this.mark = mark;
}


public Mark getMark() {
return mark;
}


// return a Move to place
public abstract Move decideMove(Board board);
}