import java.util.List;
import java.util.Random;


public class AIPlayer extends Player {
private final Random rand = new Random();


public AIPlayer(Mark mark) {
super(mark);
}


@Override
public Move decideMove(Board board) {
// Simple AI: pick a random available move. You can improve this to Minimax.
List<Move> moves = board.availableMoves();
if (moves.isEmpty()) return null;
return moves.get(rand.nextInt(moves.size()));
}
}