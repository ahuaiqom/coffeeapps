import 'coffee_model.dart';

class Order {
  final String id;
  final Coffee coffee;
  int quantity;
  final String size; // S, M, L
  final String address;
  final double deliveryFee;
  final DateTime createdAt;

  Order({
    required this.id,
    required this.coffee,
    this.quantity = 1,
    this.size = "M",
    required this.address,
    this.deliveryFee = 1.0,
    required this.createdAt,
  });

  double get totalPrice => (coffee.price * quantity) + deliveryFee;
}
