class Coffee {
  final String id;
  final String name;
  final String category;
  final double price;
  final String image; // path ke asset
  final double rating;

  Coffee({
    required this.id,
    required this.name,
    required this.category,
    required this.price,
    required this.image,
    required this.rating,
  });
}
