class User {
  final String id;
  final String name;
  final String email;
  final String address;
  final String avatar; // path ke asset / network image

  User({
    required this.id,
    required this.name,
    required this.email,
    required this.address,
    required this.avatar,
  });
}
