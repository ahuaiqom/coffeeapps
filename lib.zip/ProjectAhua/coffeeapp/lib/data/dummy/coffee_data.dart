import '../models/coffee_model.dart';

final List<Coffee> coffeeList = [
  Coffee(
    id: "1",
    name: "Caffe Mocha",
    category: "Deep Foam",
    price: 4.53,
    image: "assets/images/coffee.jpg",
    rating: 4.8,
  ),
  Coffee(
    id: "2",
    name: "Flat White",
    category: "Espresso",
    price: 3.53,
    image: "assets/images/Flat_white.jpg",
    rating: 4.2,
  ),
  Coffee(
    id: "3",
    name: "Latte",
    category: "Milk Coffee",
    price: 4.10,
    image: "assets/images/caramelmachiato.jpg",
    rating: 4.6,
  ),
];
