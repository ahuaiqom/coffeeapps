import 'package:coffee_app/presentation/screens/home/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:coffee_app/presentation/screens/home/home_screen.dart';

void main() {
  runApp(const CoffeeApp());
}

class CoffeeApp extends StatelessWidget {
  const CoffeeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Coffee UI',
      theme: ThemeData(
        fontFamily: 'Inter',
        scaffoldBackgroundColor:Colors.white,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
