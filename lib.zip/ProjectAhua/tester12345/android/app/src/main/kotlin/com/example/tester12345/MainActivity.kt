package com.example.tester12345

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
